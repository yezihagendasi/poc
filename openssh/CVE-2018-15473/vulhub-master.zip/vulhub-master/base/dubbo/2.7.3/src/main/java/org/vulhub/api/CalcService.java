package org.vulhub.api;

public interface CalcService {
    Integer add(Integer a, Integer b);
    Integer minus(Integer a, Integer b);
}
